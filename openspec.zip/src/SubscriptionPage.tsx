import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import type { BillingCycle, PlanId, Workspace } from './api'
import { Check } from './icons'
import { IOS_EASE, IOS_LIQUID_SPRING, IOS_SLIDER_SPRING, IOS_SNAPPY_SPRING } from './motion'
import {
  SUBSCRIPTION_CYCLES,
  SUBSCRIPTION_TIERS,
  cycleMetaFor,
  formatActivePlanLabel,
  isTierCycleActive,
  normalizeSubscriptionCycle,
  subscriptionButtonLabel,
} from './subscriptionLogic'
import type { SubscriptionCycleId } from './subscriptionLogic'

type SubscriptionPageProps = {
  workspace: Workspace
  busy: boolean
  error: string
  onSelectPlan(plan: PlanId, billingCycle: BillingCycle): Promise<boolean>
}

export function SubscriptionPage({
  workspace,
  busy,
  error,
  onSelectPlan,
}: SubscriptionPageProps) {
  const currentPlan = workspace.settings.plan
  const currentCycle = workspace.settings.billingCycle
  const [selectedCycle, setSelectedCycle] = useState<SubscriptionCycleId>(() =>
    normalizeSubscriptionCycle(workspace.settings.billingCycle),
  )
  const [pendingPlan, setPendingPlan] = useState<PlanId | null>(null)
  const [statusMessage, setStatusMessage] = useState('')

  useEffect(() => {
    setSelectedCycle(normalizeSubscriptionCycle(workspace.settings.billingCycle))
  }, [workspace.settings.billingCycle])

  useEffect(() => {
    if (!statusMessage) return
    const timer = setTimeout(() => setStatusMessage(''), 3000)
    return () => clearTimeout(timer)
  }, [statusMessage])

  const cycleMeta = cycleMetaFor(selectedCycle)

  async function choosePlan(plan: PlanId, billingCycle: BillingCycle) {
    if (busy || pendingPlan) return
    if (currentPlan === plan && (plan === 'free' || currentCycle === billingCycle)) return
    setPendingPlan(plan)
    setStatusMessage('')
    try {
      const ok = await onSelectPlan(plan, billingCycle)
      if (ok) {
        setStatusMessage(`เปลี่ยนแผนเป็น ${formatActivePlanLabel(plan, billingCycle)} แล้ว`)
      }
    } finally {
      setPendingPlan(null)
    }
  }

  return (
    <div className="sub-page">
      <div className="sub-shell">
        <header className="sub-header">
          <div className="sub-header-copy">
            <h1>Subscription</h1>
            <p className="sub-active-line">
              <span>แผนปัจจุบัน</span>
              <span aria-hidden="true">·</span>
              <strong className="tabular-nums">
                {formatActivePlanLabel(currentPlan, currentCycle)}
              </strong>
            </p>
          </div>

          <div className="sub-header-actions">
            <div className="sub-cycles" role="tablist" aria-label="รอบการชำระเงิน">
              {SUBSCRIPTION_CYCLES.map(cycle => {
                const isSelected = selectedCycle === cycle.id
                return (
                  <button
                    key={cycle.id}
                    type="button"
                    role="tab"
                    aria-selected={isSelected}
                    className={'sub-cycle-btn' + (isSelected ? ' on' : '')}
                    disabled={busy || pendingPlan !== null}
                    onClick={() => setSelectedCycle(cycle.id)}
                  >
                    {isSelected && (
                      <motion.span
                        layoutId="sub-cycle-pill"
                        className="sub-cycle-pill"
                        transition={IOS_SNAPPY_SPRING}
                        aria-hidden="true"
                      />
                    )}
                    <span className="relative z-1">{cycle.label}</span>
                  </button>
                )
              })}
            </div>

            {currentPlan !== 'free' && (
              <motion.button
                type="button"
                className="sub-reset-btn"
                disabled={busy || pendingPlan !== null}
                whileTap={busy ? undefined : { scale: 0.97 }}
                transition={IOS_SNAPPY_SPRING}
                onClick={() => void choosePlan('free', selectedCycle)}
              >
                สลับกลับเป็น Plan Free
              </motion.button>
            )}
          </div>
        </header>

        <div className="sub-grid" role="list" aria-label="แผนการสมัครสมาชิก">
          {SUBSCRIPTION_TIERS.map((tier, index) => {
            const active = isTierCycleActive(currentPlan, currentCycle, tier.id, selectedCycle)
            const isSolid = tier.variant === 'solid'
            const label = subscriptionButtonLabel(
              tier,
              currentPlan,
              currentCycle,
              selectedCycle,
              pendingPlan,
            )
            const price = tier.prices[selectedCycle]

            return (
              <motion.article
                key={tier.id}
                role="listitem"
                className={
                  'sub-card' +
                  (isSolid ? ' sub-card-plus' : '') +
                  (active ? ' is-active' : '')
                }
                initial={{ opacity: 0, y: 12, scale: 0.985 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ ...IOS_LIQUID_SPRING, delay: index * 0.05 }}
              >
                <div className="sub-card-top">
                  <span className="sub-kicker">{tier.label}</span>

                  <div className="sub-price-row">
                    <AnimatePresence mode="popLayout" initial={false}>
                      <motion.span
                        key={tier.id + '-' + selectedCycle + '-price'}
                        className="sub-price tabular-nums"
                        initial={{ opacity: 0, y: 6, filter: 'blur(3px)' }}
                        animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                        exit={{ opacity: 0, y: -6, filter: 'blur(3px)' }}
                        transition={IOS_SLIDER_SPRING}
                      >
                        {price}
                      </motion.span>
                    </AnimatePresence>
                    <AnimatePresence mode="popLayout" initial={false}>
                      <motion.span
                        key={tier.id + '-' + selectedCycle + '-cadence'}
                        className="sub-cadence"
                        initial={{ opacity: 0, y: 4 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -4 }}
                        transition={{ duration: 0.16, ease: IOS_EASE }}
                      >
                        {cycleMeta.cadence}
                      </motion.span>
                    </AnimatePresence>
                  </div>

                  <ul className="sub-features">
                    {tier.features.map(feature => (
                      <li key={feature} className="sub-feature-item">
                        {tier.bulletStyle === 'square' ? (
                          <span className="sub-bullet-square" aria-hidden="true" />
                        ) : (
                          <span className="sub-bullet-plus" aria-hidden="true">+</span>
                        )}
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <motion.button
                  type="button"
                  className={
                    'sub-cta ' +
                    (isSolid ? 'sub-cta-solid' : 'sub-cta-outline') +
                    (active ? ' is-current' : '')
                  }
                  disabled={busy || pendingPlan !== null || active}
                  aria-pressed={active}
                  whileTap={busy || active ? undefined : { scale: 0.985 }}
                  transition={IOS_SNAPPY_SPRING}
                  onClick={() => void choosePlan(tier.id, selectedCycle)}
                >
                  {active && <Check size={14} />}
                  <span>{label}</span>
                </motion.button>
              </motion.article>
            )
          })}
        </div>

        <div className="sub-feedback-slot" aria-live="polite">
          <AnimatePresence mode="wait">
            {error ? (
              <motion.p
                key={error}
                className="error sub-error"
                role="alert"
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                transition={{ duration: 0.16, ease: IOS_EASE }}
              >
                {error}
              </motion.p>
            ) : statusMessage ? (
              <motion.p
                key={statusMessage}
                className="sub-status"
                role="status"
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                transition={{ duration: 0.16, ease: IOS_EASE }}
              >
                {statusMessage}
              </motion.p>
            ) : null}
          </AnimatePresence>
        </div>
      </div>
    </div>
  )
}
