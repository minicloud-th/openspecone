import { useEffect, useRef, useState } from 'react'
import Markdown from 'react-markdown'
import type { Components } from 'react-markdown'
import type { Turn } from './api'
import { copyText } from './clipboard'
import { Check, Copy } from './icons'

function CopyButton({ label, getText }: { label: string; getText(): string }) {
  const [status, setStatus] = useState<'idle' | 'copied' | 'failed'>('idle')

  useEffect(() => {
    if (status === 'idle') return
    const timeout = window.setTimeout(() => setStatus('idle'), 2400)
    return () => window.clearTimeout(timeout)
  }, [status])

  return (
    <span className="reply-copy">
      <button type="button" className="oc-copy-btn" aria-label={label}
        onClick={async () => setStatus(await copyText(getText()) ? 'copied' : 'failed')}>
        {status === 'copied' ? <Check size={14} /> : <Copy size={14} />}
        {status === 'copied' ? 'คัดลอกแล้ว' : label}
      </button>
      <span className="sr-only" role="status">{status === 'copied' && 'คัดลอกแล้ว'}</span>
      {status === 'failed' && <span role="status">คัดลอกอัตโนมัติไม่สำเร็จ</span>}
    </span>
  )
}

const markdownComponents: Components = {
  pre: function CodeBlock({ children }) {
    const code = useRef<HTMLPreElement>(null)
    return (
      <div className="reply-code">
        <CopyButton label="คัดลอกโค้ด" getText={() => code.current?.textContent ?? ''} />
        <pre ref={code}>{children}</pre>
      </div>
    )
  },
}

export function ReplyContent({ turn }: { turn: Turn }) {
  return (
    <>
      <div className="reply-toolbar">
        <div className="message-by">{turn.model}</div>
        {turn.reply && <CopyButton label="คัดลอกคำตอบ" getText={() => turn.reply} />}
      </div>
      {turn.model === 'Workspace'
        ? <div className="plain-reply">{turn.reply}</div>
        : <Markdown components={markdownComponents} skipHtml disallowedElements={['img', 'a']} unwrapDisallowed>{turn.reply}</Markdown>}
    </>
  )
}
