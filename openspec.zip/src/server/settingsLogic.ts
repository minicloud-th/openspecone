import { byteLength } from '../api.ts';
import { isStoredProfileImage } from '../profileImage.ts';
import type {
  AccentColor,
  BillingCycle,
  ConnectorSettings,
  DashboardStats,
  LanguagePreference,
  PlanId,
  ThemePreference,
  Workspace,
  WorkspaceSettings,
} from './types.ts';

export const ALLOWED_THEMES = new Set<ThemePreference>(['dark', 'light', 'system']);
export const ALLOWED_ACCENT_COLORS = new Set<AccentColor>([
  '#4a8dff',
  '#2f6df0',
  '#1fa3e8',
  '#a855f7',
  '#ec4899',
  '#f59e0b',
  '#84cc16',
  '#8b8b92',
]);
export const ALLOWED_LANGUAGES = new Set<LanguagePreference>(['th', 'en', 'ja']);
export const ALLOWED_TIMEZONES = new Set<string>([
  'Asia/Bangkok',
  'UTC',
  'America/New_York',
  'Asia/Tokyo',
]);
export const ALLOWED_PLANS = new Set<PlanId>(['free', 'go', 'go_plus', 'lite', 'pro', 'max']);
export const ALLOWED_BILLING_CYCLES = new Set<BillingCycle>(['daily', 'weekly', 'monthly', 'quarterly', 'annually']);
export const ALLOWED_CONNECTORS = new Set<keyof ConnectorSettings>([
  'telegram',
  'discord',
  'line',
  'github',
]);

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function defaultSettings(): WorkspaceSettings {
  return {
    theme: 'dark',
    accentColor: '#4a8dff',
    language: 'th',
    timezone: 'Asia/Bangkok',
    email: '',
    plan: 'free',
    billingCycle: 'monthly',
    improveModel: false,
    connectors: {
      telegram: false,
      discord: false,
      line: false,
      github: false,
    },
  };
}

export function normalizeSettings(raw?: Partial<WorkspaceSettings> | null): WorkspaceSettings {
  const base = defaultSettings();
  if (!raw || typeof raw !== 'object') {
    return base;
  }

  if (isStoredProfileImage(raw.avatar)) base.avatar = raw.avatar;
  if (raw.theme && ALLOWED_THEMES.has(raw.theme)) {
    base.theme = raw.theme;
  }
  if (raw.accentColor && ALLOWED_ACCENT_COLORS.has(raw.accentColor)) {
    base.accentColor = raw.accentColor;
  }
  if (raw.language && ALLOWED_LANGUAGES.has(raw.language)) {
    base.language = raw.language;
  }
  if (typeof raw.timezone === 'string' && ALLOWED_TIMEZONES.has(raw.timezone)) {
    base.timezone = raw.timezone;
  }
  if (typeof raw.email === 'string' && raw.email.trim().length <= 120) {
    const trimmed = raw.email.trim();
    if (trimmed === '' || EMAIL_PATTERN.test(trimmed)) {
      base.email = trimmed;
    }
  }
  if (raw.plan && ALLOWED_PLANS.has(raw.plan)) {
    base.plan = raw.plan;
  }
  if (raw.billingCycle && ALLOWED_BILLING_CYCLES.has(raw.billingCycle)) {
    base.billingCycle = raw.billingCycle;
  }
  if (typeof raw.improveModel === 'boolean') {
    base.improveModel = raw.improveModel;
  }
  if (raw.connectors && typeof raw.connectors === 'object') {
    for (const key of ALLOWED_CONNECTORS) {
      const value = (raw.connectors as Record<string, unknown>)[key];
      if (typeof value === 'boolean') {
        base.connectors[key] = value;
      }
    }
  }
  return base;
}

export function validateAndMergeSettings(
  current: WorkspaceSettings,
  patch: Record<string, unknown>,
): { ok: true; next: WorkspaceSettings } | { ok: false; error: string } {
  const next: WorkspaceSettings = {
    ...current,
    connectors: { ...current.connectors },
  };

  if ('avatar' in patch) {
    if (patch.avatar === '') {
      delete next.avatar;
    } else if (isStoredProfileImage(patch.avatar)) {
      next.avatar = patch.avatar;
    } else {
      return { ok: false, error: 'รูปโปรไฟล์ไม่ถูกต้อง' };
    }
  }

  if ('theme' in patch) {
    if (typeof patch.theme !== 'string' || !ALLOWED_THEMES.has(patch.theme as ThemePreference)) {
      return { ok: false, error: 'รูปแบบธีมไม่ถูกต้อง' };
    }
    next.theme = patch.theme as ThemePreference;
  }

  if ('accentColor' in patch) {
    if (
      typeof patch.accentColor !== 'string' ||
      !ALLOWED_ACCENT_COLORS.has(patch.accentColor as AccentColor)
    ) {
      return { ok: false, error: 'สีธีมที่เลือกไม่ถูกต้อง' };
    }
    next.accentColor = patch.accentColor as AccentColor;
  }

  if ('language' in patch) {
    if (
      typeof patch.language !== 'string' ||
      !ALLOWED_LANGUAGES.has(patch.language as LanguagePreference)
    ) {
      return { ok: false, error: 'ภาษาที่เลือกไม่รองรับ' };
    }
    next.language = patch.language as LanguagePreference;
  }

  if ('timezone' in patch) {
    if (typeof patch.timezone !== 'string' || !ALLOWED_TIMEZONES.has(patch.timezone)) {
      return { ok: false, error: 'เขตเวลาที่เลือกไม่ถูกต้อง' };
    }
    next.timezone = patch.timezone;
  }

  if ('email' in patch) {
    if (typeof patch.email !== 'string') {
      return { ok: false, error: 'รูปแบบอีเมลไม่ถูกต้อง' };
    }
    const email = patch.email.trim();
    if (email.length > 120 || (email !== '' && !EMAIL_PATTERN.test(email))) {
      return { ok: false, error: 'กรุณากรอกอีเมลให้ถูกต้อง (ไม่เกิน 120 ตัวอักษร)' };
    }
    next.email = email;
  }

  if ('plan' in patch) {
    if (typeof patch.plan !== 'string' || !ALLOWED_PLANS.has(patch.plan as PlanId)) {
      return { ok: false, error: 'แพ็กเกจที่เลือกไม่ถูกต้อง' };
    }
    next.plan = patch.plan as PlanId;
  }

  if ('billingCycle' in patch) {
    if (
      typeof patch.billingCycle !== 'string' ||
      !ALLOWED_BILLING_CYCLES.has(patch.billingCycle as BillingCycle)
    ) {
      return { ok: false, error: 'รอบบิลที่เลือกไม่ถูกต้อง' };
    }
    next.billingCycle = patch.billingCycle as BillingCycle;
  }

  if ('improveModel' in patch) {
    if (typeof patch.improveModel !== 'boolean') {
      return { ok: false, error: 'ค่าสถานะความเป็นส่วนตัวไม่ถูกต้อง' };
    }
    next.improveModel = patch.improveModel;
  }

  if ('connectors' in patch) {
    if (!patch.connectors || typeof patch.connectors !== 'object' || Array.isArray(patch.connectors)) {
      return { ok: false, error: 'ข้อมูลการเชื่อมต่อไม่ถูกต้อง' };
    }
    const entries = Object.entries(patch.connectors as Record<string, unknown>);
    for (const [key, value] of entries) {
      if (!ALLOWED_CONNECTORS.has(key as keyof ConnectorSettings) || typeof value !== 'boolean') {
        return { ok: false, error: 'ข้อมูลการเชื่อมต่อไม่ถูกต้อง' };
      }
      next.connectors[key as keyof ConnectorSettings] = value;
    }
  }

  return { ok: true, next };
}

export async function publicWorkspaceId(rawId: string): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`bluezycode:${rawId}`));
  const hash = Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('');
  return `bz_${hash.slice(0, 14)}`;
}

function dayKeyInZone(date: Date, timeZone: string): string {
  try {
    return new Intl.DateTimeFormat('en-CA', {
      timeZone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(date);
  } catch {
    return date.toISOString().slice(0, 10);
  }
}

export function computeDashboardStats(
  ws: Workspace,
  maxStorageBytes: number,
  now = new Date(),
): DashboardStats {
  const tz = normalizeSettings(ws.settings).timezone;
  const todayKey = dayKeyInZone(now, tz);
  const activeChats = ws.chats ?? [];
  const archived = ws.archivedChats ?? [];
  const allChats = [...activeChats, ...archived];

  let totalTurns = 0;
  let todayTurns = 0;
  let totalFiles = 0;
  let charCount = 0;

  for (const chat of allChats) {
    const updatedDate = new Date(chat.updated);
    const isToday = !Number.isNaN(updatedDate.getTime()) && dayKeyInZone(updatedDate, tz) === todayKey;
    totalTurns += chat.turns.length;
    if (isToday) {
      todayTurns += chat.turns.length;
    }
    for (const turn of chat.turns) {
      totalFiles += turn.files.length;
      charCount += (turn.prompt?.length ?? 0) + (turn.reply?.length ?? 0);
      for (const file of turn.files) {
        charCount += (file.name?.length ?? 0) + (file.content?.length ?? 0);
      }
    }
  }

  const estimatedTokens = charCount === 0 ? 0 : Math.ceil(charCount / 3.5);
  const storageBytes = byteLength(JSON.stringify(ws));

  return {
    totalChats: activeChats.length,
    archivedChats: archived.length,
    chatLimit: 40,
    totalTurns,
    todayTurns,
    totalFiles,
    estimatedTokens,
    storageBytes,
    maxStorageBytes,
  };
}
