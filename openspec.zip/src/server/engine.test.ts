import assert from 'node:assert/strict';
import test from 'node:test';
import { analyzeText, MAX_ENGINE_BYTES } from './engine.ts';

test('reports unicode lines and note positions matching Rust engine', () => {
  const metrics = analyzeText('กข\r\n\r\n// TODO: test\nTODOS\n');
  assert.equal(metrics.lines, 4);
  assert.equal(metrics.non_blank, 3);
  assert.equal(metrics.longest, 13);
  assert.equal(metrics.notes.length, 1);
  assert.equal(metrics.notes[0].line, 3);
  assert.equal(metrics.notes[0].text, '// TODO: test');
  assert.equal(analyzeText('').lines, 0);
});

test('caps notes at 8 and truncates note text to 180 code points', () => {
  const longComment = '// FIXME: ' + 'ก'.repeat(250);
  const lines = Array.from({ length: 10 }, (_, idx) => `${longComment} ${idx}`);
  const metrics = analyzeText(lines.join('\n'));
  assert.equal(metrics.lines, 10);
  assert.equal(metrics.notes.length, 8);
  assert.equal([...metrics.notes[0].text].length, 180);
});

test('rejects null bytes and oversized files', () => {
  assert.throws(() => analyzeText('hello\0world'), /text file/);
  assert.throws(() => analyzeText('a'.repeat(MAX_ENGINE_BYTES + 1)), /64 KiB/);
});
