import crypto from 'node:crypto';

export const DISCORD_AUTHORIZE_URL = 'https://discord.com/oauth2/authorize';
export const DISCORD_TOKEN_URL = 'https://discord.com/api/oauth2/token';
export const DISCORD_REVOKE_URL = 'https://discord.com/api/oauth2/token/revoke';
export const DISCORD_USER_ME_URL = 'https://discord.com/api/v10/users/@me';
export const DISCORD_ISSUER = 'https://discord.com';
export const DISCORD_DEFAULT_SCOPE = 'identify email';
export const DISCORD_SESSION_COOKIE = 'openspec_discord_session';

export type DiscordApiUser = {
  id: string;
  username: string;
  global_name?: string | null;
  avatar?: string | null;
  discriminator?: string;
  email?: string | null;
  verified?: boolean;
};

export type DiscordSessionUser = {
  id: string;
  discordId: string;
  name: string;
  email: string;
  provider: 'discord';
  photoURL?: string;
};

export function resolveAppBaseUrl(appUrlEnv?: string): string {
  const candidate = appUrlEnv?.trim();
  if (!candidate || candidate === 'MY_APP_URL') {
    return 'http://localhost:3000';
  }
  try {
    const parsed = new URL(candidate);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return 'http://localhost:3000';
    }
    return parsed.origin;
  } catch {
    return 'http://localhost:3000';
  }
}

export function getDiscordRedirectUri(appUrlEnv?: string, explicitRedirectUri?: string): string {
  const explicit = explicitRedirectUri?.trim();
  if (explicit) {
    try {
      const parsed = new URL(explicit);
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
        return parsed.toString().replace(/\/+$/, '');
      }
    } catch {
      // Fall back to APP_URL-derived callback path.
    }
  }
  return `${resolveAppBaseUrl(appUrlEnv)}/auth/discord/callback`;
}

export function buildDiscordAuthorizeUrl(input: {
  clientId: string;
  redirectUri: string;
  state: string;
  scope?: string;
}): string {
  const params = new URLSearchParams({
    response_type: 'code',
    client_id: input.clientId,
    redirect_uri: input.redirectUri,
    scope: input.scope || DISCORD_DEFAULT_SCOPE,
    state: input.state,
    prompt: 'consent',
  });
  return `${DISCORD_AUTHORIZE_URL}?${params.toString()}`;
}

export function isValidDiscordIssuer(iss?: string | null): boolean {
  if (iss === undefined || iss === null || iss === '') {
    return true;
  }
  return iss === DISCORD_ISSUER;
}

export function discordAvatarUrl(userId: string, avatarHash?: string | null): string | undefined {
  if (!/^\d{15,22}$/.test(userId) || !avatarHash || !/^(?:a_)?[a-fA-F0-9]{16,64}$/.test(avatarHash)) {
    return undefined;
  }
  const ext = avatarHash.startsWith('a_') ? 'gif' : 'png';
  return `https://cdn.discordapp.com/avatars/${userId}/${avatarHash}.${ext}?size=128`;
}

export function toDiscordSessionUser(user: DiscordApiUser): DiscordSessionUser {
  const displayName = user.global_name?.trim() || user.username.trim() || 'Discord User';
  return {
    id: `discord:${user.id}`,
    discordId: user.id,
    name: displayName.slice(0, 40),
    email: user.email?.trim() || '',
    provider: 'discord',
    photoURL: discordAvatarUrl(user.id, user.avatar),
  };
}

export function createStateStore(ttlMs = 10 * 60 * 1000) {
  const pending = new Map<string, number>();

  function prune(now: number) {
    for (const [key, expiresAt] of pending) {
      if (expiresAt <= now) {
        pending.delete(key);
      }
    }
  }

  return {
    issue(now = Date.now()): string {
      prune(now);
      const state = crypto.randomBytes(24).toString('base64url');
      pending.set(state, now + ttlMs);
      return state;
    },
    consume(state: string | undefined, now = Date.now()): boolean {
      prune(now);
      if (!state || typeof state !== 'string') return false;
      const expiresAt = pending.get(state);
      if (!expiresAt) return false;
      pending.delete(state);
      return expiresAt > now;
    },
  };
}

export function createTicketStore<T>(ttlMs = 2 * 60 * 1000) {
  const tickets = new Map<string, { value: T; expiresAt: number }>();

  function prune(now: number) {
    for (const [key, entry] of tickets) {
      if (entry.expiresAt <= now) {
        tickets.delete(key);
      }
    }
  }

  return {
    issue(value: T, now = Date.now()): string {
      prune(now);
      const ticket = crypto.randomBytes(32).toString('base64url');
      tickets.set(ticket, { value, expiresAt: now + ttlMs });
      return ticket;
    },
    consume(ticket: string | undefined, now = Date.now()): T | null {
      prune(now);
      if (!ticket || typeof ticket !== 'string') return null;
      const entry = tickets.get(ticket);
      if (!entry) return null;
      tickets.delete(ticket);
      return entry.expiresAt > now ? entry.value : null;
    },
  };
}

export function signSessionToken(
  user: DiscordSessionUser,
  secret: string,
  ttlSeconds = 7 * 24 * 60 * 60,
  nowSec = Math.floor(Date.now() / 1000),
): string {
  const payload = Buffer.from(
    JSON.stringify({
      user,
      iat: nowSec,
      exp: nowSec + ttlSeconds,
    }),
    'utf8',
  ).toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

export function verifySessionToken(
  token: string | undefined,
  secret: string,
  nowSec = Math.floor(Date.now() / 1000),
): DiscordSessionUser | null {
  if (!token || typeof token !== 'string') return null;
  const dot = token.indexOf('.');
  if (dot <= 0 || dot === token.length - 1) return null;
  const payload = token.slice(0, dot);
  const sig = token.slice(dot + 1);
  const expectedSig = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expectedBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(sigBuf, expectedBuf)) {
    return null;
  }
  try {
    const parsed = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as {
      user?: DiscordSessionUser;
      exp?: number;
    };
    if (!parsed || typeof parsed.exp !== 'number' || parsed.exp <= nowSec) {
      return null;
    }
    const u = parsed.user;
    if (!u || typeof u.id !== 'string' || !u.id.startsWith('discord:') || u.provider !== 'discord') {
      return null;
    }
    return u;
  } catch {
    return null;
  }
}

export function parseCookieHeader(header: string | undefined): Record<string, string> {
  const result: Record<string, string> = {};
  if (!header) return result;
  for (const part of header.split(';')) {
    const idx = part.indexOf('=');
    if (idx <= 0) continue;
    const name = part.slice(0, idx).trim();
    const rawValue = part.slice(idx + 1).trim();
    try {
      result[name] = decodeURIComponent(rawValue);
    } catch {
      result[name] = rawValue;
    }
  }
  return result;
}

export function serializeScriptJson(value: unknown): string {
  return JSON.stringify(value)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/&/g, '\\u0026')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');
}

export function renderOAuthPopupHtml(
  payload:
    | { type: 'DISCORD_OAUTH_SUCCESS'; ticket: string; user: DiscordSessionUser }
    | { type: 'DISCORD_OAUTH_ERROR'; error: string },
): string {
  const serialized = serializeScriptJson(payload);
  const statusText = payload.type === 'DISCORD_OAUTH_SUCCESS'
    ? 'เชื่อมต่อ Discord สำเร็จ กำลังกลับไปยัง OPENSPEC...'
    : 'ไม่สามารถเชื่อมต่อ Discord ได้ กรุณาปิดหน้าต่างนี้แล้วลองอีกครั้ง';

  return `<!doctype html>
<html lang="th">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>OPENSPEC · Discord OAuth</title>
    <style>
      body { margin: 0; font-family: system-ui, -apple-system, sans-serif; background: #0b0b0d; color: #ededed; display: grid; place-items: center; min-height: 100vh; text-align: center; padding: 24px; }
      p { color: #a1a1aa; font-size: 14px; line-height: 1.6; max-width: 360px; }
    </style>
  </head>
  <body>
    <main>
      <p id="status">${statusText}</p>
    </main>
    <script>
      (function () {
        var data = ${serialized};
        if (window.opener) {
          window.opener.postMessage(data, '*');
          window.close();
        } else {
          window.location.href = '/';
        }
      })();
    </script>
  </body>
</html>`;
}
