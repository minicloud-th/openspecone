import type { AttachmentPreview } from '../attachmentTypes';

export type FileAttachment = {
  name: string;
  content?: string;
  preview?: AttachmentPreview;
};

export type ValidFileAttachment = {
  name: string;
  content: string;
  preview?: AttachmentPreview;
};

export type Turn = {
  prompt: string;
  reply: string;
  model: string;
  files: FileAttachment[];
};

export type Chat = {
  id: string;
  title: string;
  updated: string;
  turns: Turn[];
  redo?: Turn[];
};

export type ChatSummary = {
  id: string;
  title: string;
  updated: string;
};

export type ThemePreference = 'dark' | 'light' | 'system';
export type AccentColor =
  | '#4a8dff'
  | '#2f6df0'
  | '#1fa3e8'
  | '#a855f7'
  | '#ec4899'
  | '#f59e0b'
  | '#84cc16'
  | '#8b8b92';
export type LanguagePreference = 'th' | 'en' | 'ja';
export type PlanId = 'free' | 'go' | 'go_plus' | 'lite' | 'pro' | 'max';
export type BillingCycle = 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'annually';

export type ConnectorSettings = {
  telegram: boolean;
  discord: boolean;
  line: boolean;
  github: boolean;
};

export type WorkspaceSettings = {
  avatar?: string;
  theme: ThemePreference;
  accentColor: AccentColor;
  language: LanguagePreference;
  timezone: string;
  email: string;
  plan: PlanId;
  billingCycle: BillingCycle;
  improveModel: boolean;
  connectors: ConnectorSettings;
};

export type DashboardStats = {
  totalChats: number;
  archivedChats: number;
  chatLimit: number;
  totalTurns: number;
  todayTurns: number;
  totalFiles: number;
  estimatedTokens: number;
  storageBytes: number;
  maxStorageBytes: number;
};

export type Workspace = {
  name: string;
  chats: Chat[];
  archivedChats?: Chat[];
  settings?: WorkspaceSettings;
};

export type Model = {
  id: string;
  name: string;
};

export type SendRequest = {
  chatId: string;
  prompt: string;
  model: string;
  effort?: 'Low' | 'Medium' | 'High' | 'Max';
  files: ValidFileAttachment[];
};

export type Note = {
  line: number;
  text: string;
};

export type Analysis = {
  bytes: number;
  lines: number;
  non_blank: number;
  longest: number;
  notes: Note[];
};
