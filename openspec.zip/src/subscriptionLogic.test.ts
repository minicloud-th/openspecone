import test from 'node:test'
import assert from 'node:assert/strict'
import {
  SUBSCRIPTION_CYCLES,
  SUBSCRIPTION_TIERS,
  cycleMetaFor,
  formatActivePlanLabel,
  formatCycleLabel,
  isTierCycleActive,
  normalizeSubscriptionCycle,
  subscriptionButtonLabel,
} from './subscriptionLogic'

test('SUBSCRIPTION_CYCLES exposes daily, weekly, monthly, and annually in order', () => {
  assert.deepEqual(
    SUBSCRIPTION_CYCLES.map(item => [item.id, item.label, item.cadence]),
    [
      ['daily', 'รายวัน', 'per day'],
      ['weekly', 'รายสัปดาห์', 'per week'],
      ['monthly', 'รายเดือน', 'per month'],
      ['annually', 'รายปี', 'per year'],
    ],
  )
})

test('SUBSCRIPTION_TIERS defines GO and GO PLUS prices across all 4 cycles', () => {
  assert.equal(SUBSCRIPTION_TIERS.length, 2)

  const [go, goPlus] = SUBSCRIPTION_TIERS
  assert.equal(go.id, 'go')
  assert.deepEqual(go.prices, {
    daily: '฿35',
    weekly: '฿140',
    monthly: '฿350',
    annually: '฿3,360',
  })
  assert.equal(go.bulletStyle, 'square')
  assert.equal(go.variant, 'outline')

  assert.equal(goPlus.id, 'go_plus')
  assert.deepEqual(goPlus.prices, {
    daily: '฿105',
    weekly: '฿490',
    monthly: '฿1,400',
    annually: '฿13,440',
  })
  assert.equal(goPlus.bulletStyle, 'plus')
  assert.equal(goPlus.variant, 'solid')
})

test('isTierCycleActive and subscriptionButtonLabel distinguish current vs switched cycle', () => {
  const [go, goPlus] = SUBSCRIPTION_TIERS
  assert.equal(isTierCycleActive('free', 'monthly', 'go', 'monthly'), false)
  assert.equal(isTierCycleActive('go', 'monthly', 'go', 'monthly'), true)
  assert.equal(isTierCycleActive('go', 'monthly', 'go', 'annually'), false)

  assert.equal(subscriptionButtonLabel(go, 'free', 'monthly', 'daily'), 'SUBSCRIBE TO GO')
  assert.equal(subscriptionButtonLabel(go, 'go', 'monthly', 'monthly'), 'CURRENT PLAN · GO')
  assert.equal(subscriptionButtonLabel(go, 'go', 'monthly', 'annually'), 'SWITCH CYCLE · GO')
  assert.equal(subscriptionButtonLabel(goPlus, 'free', 'monthly', 'weekly', 'go_plus'), 'UPDATING...')
})

test('cycle normalization and plan labels format cleanly', () => {
  assert.equal(normalizeSubscriptionCycle('daily'), 'daily')
  assert.equal(normalizeSubscriptionCycle('quarterly'), 'monthly')
  assert.equal(cycleMetaFor('weekly').cadence, 'per week')
  assert.equal(formatCycleLabel('daily'), 'รายวัน')
  assert.equal(formatCycleLabel('weekly'), 'รายสัปดาห์')
  assert.equal(formatCycleLabel('monthly'), 'รายเดือน')
  assert.equal(formatCycleLabel('annually'), 'รายปี')
  assert.equal(formatActivePlanLabel('free'), 'Plan Free')
  assert.equal(formatActivePlanLabel('free', 'daily'), 'Plan Free')
  assert.equal(formatActivePlanLabel('go', 'weekly'), 'Plan Go (รายสัปดาห์)')
  assert.equal(formatActivePlanLabel('go_plus', 'annually'), 'Plan Go Plus (รายปี)')
})
