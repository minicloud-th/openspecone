import { byteLength } from './api'
import type { Attachment } from './api'
import { attachmentExtension, hasImageExtension } from './attachmentTypes'
import { imageDimensions, imageSizeAllowed, MAX_IMAGE_PIXELS, MAX_IMAGE_SIDE } from './imageDimensions'
import { MAX_FILE_BYTES } from './server/chatLogic'

const MAX_PREVIEW_SOURCE = 10 * 1024 * 1024
const archiveTextExtensions = new Set('txt md json csv tsv xml html css scss js jsx ts tsx py go rs java kt c h cpp cs php rb sh sql toml yaml yml ini cfg log svg svelte vue dockerfile'.split(' '))

function textOf(buffer: Uint8Array) {
  const text = new TextDecoder('utf-8', { fatal: true }).decode(buffer)
  if (text.includes('\0')) throw new Error('Invalid text')
  return text
}

function readBytes(file: File, progress: (value: number) => void, signal: AbortSignal) {
  return new Promise<Uint8Array<ArrayBuffer>>((resolve, reject) => {
    signal.throwIfAborted()
    const reader = new FileReader()
    const abort = () => reader.abort()
    signal.addEventListener('abort', abort, { once: true })
    reader.onprogress = event => {
      if (event.lengthComputable && event.total > 0) progress(Math.round(event.loaded / event.total * 100))
    }
    reader.onload = () => {
      progress(100)
      resolve(new Uint8Array(reader.result as ArrayBuffer))
    }
    reader.onerror = () => reject(new Error('อ่านไฟล์ ' + file.name + ' ไม่สำเร็จ'))
    reader.onabort = () => reject(signal.reason)
    reader.onloadend = () => signal.removeEventListener('abort', abort)
    reader.readAsArrayBuffer(file)
  })
}

function imageType(data: Uint8Array) {
  const signature = Array.from(data.subarray(0, 12))
  const word = String.fromCharCode(...signature)
  if (signature[0] === 137 && word.slice(1, 4) === 'PNG') return 'image/png'
  if (signature[0] === 255 && signature[1] === 216 && signature[2] === 255) return 'image/jpeg'
  if (word.startsWith('GIF87a') || word.startsWith('GIF89a')) return 'image/gif'
  if (word.startsWith('RIFF') && word.slice(8) === 'WEBP') return 'image/webp'
  return null
}

async function prepareImage(file: File, data: Uint8Array<ArrayBuffer>): Promise<Attachment> {
  const size = imageDimensions(data)
  if (size && !imageSizeAllowed(size)) {
    throw new Error(`รูป ${file.name} มีขนาดพิกเซลใหญ่เกินไป (สูงสุด ${MAX_IMAGE_SIDE.toLocaleString('en-US')} พิกเซลต่อด้าน และ ${(MAX_IMAGE_PIXELS / 1_000_000).toLocaleString('en-US')} ล้านพิกเซล)`)
  }
  try {
    const type = imageType(data)
    if (!type || !size) throw new Error('Unknown image type')
    const image = await createImageBitmap(new Blob([data], { type }))
    try {
      const { width, height } = image
      const scale = Math.min(1, 256 / Math.max(width, height))
      const canvas = document.createElement('canvas')
      canvas.width = Math.max(1, Math.round(width * scale))
      canvas.height = Math.max(1, Math.round(height * scale))
      const context = canvas.getContext('2d')
      if (!context) throw new Error('Canvas unavailable')
      context.drawImage(image, 0, 0, canvas.width, canvas.height)
      const thumbnail = canvas.toDataURL('image/webp', 0.78)
      return {
        name: file.name,
        content: `Image attachment: ${width} × ${height} px, ${file.size} bytes. Preview only. The model cannot inspect the image pixels.`,
        preview: { kind: 'image', size: file.size, thumbnail, width, height },
      }
    } finally {
      image.close()
    }
  } catch {
    throw new Error('เปิดรูป ' + file.name + ' ไม่ได้ รองรับ PNG, JPG, GIF และ WebP')
  }
}

async function prepareZip(file: File, data: Uint8Array): Promise<Attachment> {
  const { unzipSync } = await import('fflate')
  const previewNames: string[] = []
  let scanned = 0
  let entries = 0
  let readBudget = 4 * 1024
  let compressedBudget = 256 * 1024
  let files: Record<string, Uint8Array>
  try {
    if (data[0] !== 0x50 || data[1] !== 0x4b) throw new Error('Invalid ZIP signature')
    files = unzipSync(data, { filter(entry) {
      if (++scanned > 5000) throw new Error('Too many entries')
      if (entry.name.endsWith('/')) return false
      entries += 1
      const safeName = entry.name.replace(/[\u0000-\u001f\u007f]/g, ' ')
      if (previewNames.length < 30) previewNames.push(safeName.slice(0, 80))
      if (entry.originalSize === 0 || entry.originalSize > readBudget || entry.size > compressedBudget ||
          (entry.compression === 0 && entry.size !== entry.originalSize) ||
          (entry.compression !== 0 && entry.compression !== 8) ||
          !archiveTextExtensions.has(attachmentExtension(entry.name))) return false
      readBudget -= entry.originalSize
      compressedBudget -= entry.size
      return true
    } })
  } catch {
    throw new Error('อ่าน ZIP ' + file.name + ' ไม่สำเร็จ รองรับ ZIP ปกติที่ไม่มีรหัสผ่านและมีไม่เกิน 5,000 ไฟล์')
  }
  const samples: string[] = []
  for (const [name, bytes] of Object.entries(files)) {
    try { samples.push(name.replace(/[\u0000-\u001f\u007f]/g, ' ').slice(0, 80) + '\n' + textOf(bytes)) }
    catch { /* Binary or differently encoded entries still appear in the list. */ }
  }
  const content = [
    `ZIP · ${entries} ไฟล์ · แสดงรายชื่อ ${previewNames.length} ไฟล์ · อ่านไฟล์ข้อความ ${samples.length} ไฟล์ในโควตา 4 KiB`,
    ...previewNames,
    ...(samples.length ? ['\nไฟล์ข้อความที่อ่านได้:', ...samples] : []),
  ].join('\n')
  if (byteLength(content) > MAX_FILE_BYTES) throw new Error('ข้อมูลสรุป ZIP ยาวเกินขีดจำกัด')
  return { name: file.name, content, preview: { kind: 'archive', size: file.size, entries, extracted: samples.length } }
}

export async function prepareAttachment(file: File, progress: (value: number) => void, signal: AbortSignal): Promise<Attachment> {
  const extension = attachmentExtension(file.name)
  const image = hasImageExtension(file.name) || ['image/png', 'image/jpeg', 'image/gif', 'image/webp'].includes(file.type)
  const archive = extension === 'zip'
  if (byteLength(file.name) > 255 || !file.name.trim() || /[/\\\x00\r\n]/.test(file.name)) {
    throw new Error('ชื่อไฟล์ยาวเกินไปหรือมีอักขระที่ไม่รองรับ')
  }
  if (file.size > (image || archive ? MAX_PREVIEW_SOURCE : MAX_FILE_BYTES)) {
    throw new Error(`${file.name} ใหญ่เกินกำหนด (${image || archive ? '10 MiB' : '64 KiB'})`)
  }
  const bytes = await readBytes(file, progress, signal)
  signal.throwIfAborted()
  if (image) return prepareImage(file, bytes)
  if (archive) return prepareZip(file, bytes)

  try {
    return { name: file.name, content: textOf(bytes), preview: { kind: 'text', size: file.size } }
  } catch {
    throw new Error(`${file.name} ไม่รองรับ แนบได้เฉพาะไฟล์ข้อความ UTF-8, ZIP, PNG, JPG, GIF หรือ WebP`)
  }
}
