const CENTER = 20
const RADIUS = 12.75
const INK_WIDTH = 1.6
const CAP_ANGLE = INK_WIDTH / 2 / RADIUS * 180 / Math.PI

function point(angle: number) {
  const radians = angle * Math.PI / 180
  return {
    x: CENTER + RADIUS * Math.cos(radians),
    y: CENTER + RADIUS * Math.sin(radians),
  }
}

function arc(start: number, end: number) {
  const a = point(start)
  const b = point(end)
  return `M ${a.x} ${a.y} A ${RADIUS} ${RADIUS} 0 ${end - start > 180 ? 1 : 0} 1 ${b.x} ${b.y}`
}

function UsageSegment({ start, end, remaining }: { start: number; end: number; remaining: number }) {
  const fill = Math.min(100, Math.max(0, remaining))
  const filledEnd = start + (end - start) * fill / 100
  const lower = Math.min(start, filledEnd)
  const upper = Math.max(start, filledEnd)
  const cap = lower + CAP_ANGLE
  const tip = point(cap < upper ? cap : (lower + upper) / 2)

  return <g>
    <path className="usage-track" d={arc(Math.min(start, end), Math.max(start, end))} />
    {fill > 0 && <>
      {cap < upper && <path className="usage-ink" d={arc(cap, upper)} strokeWidth={INK_WIDTH} />}
      <circle className="usage-tip" cx={tip.x} cy={tip.y} r={INK_WIDTH / 2} />
    </>}
  </g>
}

export function UsageIcon({ storage, chats }: { storage: number; chats: number }) {
  return <svg className="usage-glyph" viewBox="0 0 40 40" aria-hidden="true" focusable="false">
    <UsageSegment start={215.5} end={324.5} remaining={storage} />
    <UsageSegment start={195.5} end={-16.5} remaining={chats} />
    <rect className="usage-diamond" x="-4.05" y="-4.05" width="8.1" height="8.1" rx="1.15"
      transform="translate(20 20) rotate(45)" />
  </svg>
}
