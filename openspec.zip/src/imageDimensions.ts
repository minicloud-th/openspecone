// Reads pixel dimensions from the file header so oversized images are rejected
// before the browser decodes them (a small file can expand to gigabytes of pixels).
export const MAX_IMAGE_SIDE = 16384
export const MAX_IMAGE_PIXELS = 64_000_000

export type ImageSize = { width: number; height: number }

const u16be = (d: Uint8Array, i: number) => (d[i] << 8) | d[i + 1]
const u16le = (d: Uint8Array, i: number) => d[i] | (d[i + 1] << 8)
const u24le = (d: Uint8Array, i: number) => d[i] | (d[i + 1] << 8) | (d[i + 2] << 16)
const u32be = (d: Uint8Array, i: number) => ((d[i] << 24) | (d[i + 1] << 16) | (d[i + 2] << 8) | d[i + 3]) >>> 0
const u32le = (d: Uint8Array, i: number) => ((d[i + 3] << 24) | (d[i + 2] << 16) | (d[i + 1] << 8) | d[i]) >>> 0
const ascii = (d: Uint8Array, start: number, end: number) => String.fromCharCode(...d.subarray(start, end))

export function imageDimensions(data: Uint8Array): ImageSize | null {
  if (data.length >= 24 && data[0] === 0x89 && ascii(data, 1, 4) === 'PNG') {
    return { width: u32be(data, 16), height: u32be(data, 20) }
  }
  if (data.length >= 10 && ascii(data, 0, 3) === 'GIF') {
    return { width: u16le(data, 6), height: u16le(data, 8) }
  }
  if (data.length >= 30 && ascii(data, 0, 4) === 'RIFF' && ascii(data, 8, 12) === 'WEBP') {
    const kind = ascii(data, 12, 16)
    if (kind === 'VP8X') return { width: u24le(data, 24) + 1, height: u24le(data, 27) + 1 }
    if (kind === 'VP8L' && data[20] === 0x2f) {
      const bits = u32le(data, 21)
      return { width: (bits & 0x3fff) + 1, height: ((bits >>> 14) & 0x3fff) + 1 }
    }
    if (kind === 'VP8 ' && data[23] === 0x9d && data[24] === 0x01 && data[25] === 0x2a) {
      return { width: u16le(data, 26) & 0x3fff, height: u16le(data, 28) & 0x3fff }
    }
    return null
  }
  if (data.length >= 4 && data[0] === 0xff && data[1] === 0xd8) {
    let index = 2
    while (index + 9 <= data.length) {
      if (data[index] !== 0xff) {
        index += 1
        continue
      }
      const marker = data[index + 1]
      if (marker === 0xff) {
        index += 1
      } else if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) {
        index += 2
      } else if (marker === 0xda) {
        return null
      } else {
        const length = u16be(data, index + 2)
        if (length < 2) return null
        if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc) {
          return { width: u16be(data, index + 7), height: u16be(data, index + 5) }
        }
        index += 2 + length
      }
    }
  }
  return null
}

export function imageSizeAllowed(size: ImageSize | null): size is ImageSize {
  return size !== null && size.width > 0 && size.height > 0 &&
    size.width <= MAX_IMAGE_SIDE && size.height <= MAX_IMAGE_SIDE &&
    size.width * size.height <= MAX_IMAGE_PIXELS
}
