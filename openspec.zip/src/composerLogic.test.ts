import test from 'node:test'
import assert from 'node:assert/strict'
import {
  DEFAULT_SKILLS,
  EFFORT_LEVELS,
  EFFORT_MODEL_SPECS,
  buildModelWorkerRequest,
  buildPromptWithSkills,
  clampEffortRatio,
  computeSliderRatio,
  effortFromRatio,
  effortIndex,
  effortMaxTokens,
  effortStopRatio,
  formatAutoAnalysisReply,
  formatModelDisplayName,
  isLocalModelName,
  modelForEffort,
} from './composerLogic'

test('formatModelDisplayName labels local AI model as Plan Free (AI จากเครื่อง)', () => {
  assert.deepEqual(formatModelDisplayName({ id: 'ai', name: 'Qwen3 0.6B' }), {
    title: 'Plan Free',
    badge: 'AI จากเครื่อง',
  })
})

test('effortFromRatio, effortIndex, and continuous slider helpers map 4 stops cleanly', () => {
  assert.equal(EFFORT_LEVELS.length, 4)
  assert.equal(effortFromRatio(-0.2), 'Low')
  assert.equal(effortFromRatio(0.33), 'Medium')
  assert.equal(effortFromRatio(0.67), 'High')
  assert.equal(effortFromRatio(1.4), 'Max')
  assert.equal(effortIndex('Low'), 0)
  assert.equal(effortIndex('Max'), 3)
  assert.equal(clampEffortRatio(Number.NaN), 1)
  assert.equal(clampEffortRatio(-0.5), 0)
  assert.equal(clampEffortRatio(0.42), 0.42)
  assert.equal(effortStopRatio('Low'), 0)
  assert.equal(effortStopRatio('Max'), 1)
  assert.equal(computeSliderRatio(16, 0, 232, 16), 0)
  assert.equal(computeSliderRatio(216, 0, 232, 16), 1)
  assert.equal(computeSliderRatio(116, 0, 232, 16), 0.5)
})

test('effortMaxTokens scales generation budget across effort levels', () => {
  assert.ok(effortMaxTokens('Low') < effortMaxTokens('Medium'))
  assert.ok(effortMaxTokens('Medium') < effortMaxTokens('High'))
  assert.ok(effortMaxTokens('High') < effortMaxTokens('Max'))
})

test('EFFORT_MODEL_SPECS maps each Effort level on Plan Free to a progressively higher model', () => {
  const ordered = EFFORT_LEVELS.map(level => modelForEffort(level))
  const uniqueRepos = new Set(ordered.map(spec => spec.repoId))
  assert.equal(uniqueRepos.size, 4)
  for (let i = 1; i < ordered.length; i++) {
    assert.ok(ordered[i].parameterBillions > ordered[i - 1].parameterBillions)
    assert.ok(ordered[i].approxBytesMB > ordered[i - 1].approxBytesMB)
    assert.ok(ordered[i].maxNewTokens > ordered[i - 1].maxNewTokens)
  }
  for (const spec of Object.values(EFFORT_MODEL_SPECS)) {
    assert.match(spec.repoId, /^onnx-community\//)
    assert.match(spec.revision, /^[0-9a-f]{40}$/)
    assert.equal(isLocalModelName(spec.displayName), true)
  }
  assert.equal(isLocalModelName('Plan Free'), true)
  assert.equal(isLocalModelName('Workspace'), false)
})

test('buildModelWorkerRequest builds effort-specific Hugging Face ONNX payloads', () => {
  const messages = [{ role: 'user' as const, content: 'สวัสดี' }]
  const lowReq = buildModelWorkerRequest('Low', messages)
  const medReq = buildModelWorkerRequest('Medium', messages)
  const highReq = buildModelWorkerRequest('High', messages)
  const maxReq = buildModelWorkerRequest('Max', messages)

  assert.equal(lowReq.modelId, 'onnx-community/Qwen3-0.6B-ONNX-OPT')
  assert.equal(lowReq.supportsThinkingControl, true)
  assert.equal(medReq.modelId, 'onnx-community/gemma-3-1b-it-ONNX')
  assert.equal(medReq.supportsThinkingControl, false)
  assert.equal(highReq.modelId, 'onnx-community/Qwen2.5-1.5B-Instruct')
  assert.equal(highReq.dtype, 'q8')
  assert.equal(maxReq.modelId, 'onnx-community/Qwen3-1.7B-ONNX')
  assert.equal(maxReq.dtype, 'q8')
  assert.equal(maxReq.supportsThinkingControl, true)
  assert.notEqual(lowReq.modelKey, medReq.modelKey)
  assert.notEqual(medReq.modelKey, highReq.modelKey)
  assert.notEqual(highReq.modelKey, maxReq.modelKey)
})

test('buildPromptWithSkills prepends active skill instructions without losing prompt', () => {
  assert.equal(buildPromptWithSkills('  hello  ', []), 'hello')
  const combined = buildPromptWithSkills('ตรวจไฟล์นี้ให้หน่อย', [DEFAULT_SKILLS[0]])
  assert.match(combined, /\[Skill: เขียนสเปค OpenSpec\]/)
  assert.match(combined, /ตรวจไฟล์นี้ให้หน่อย$/)
})

test('formatAutoAnalysisReply combines automatic file analysis and AI reply cleanly', () => {
  assert.equal(formatAutoAnalysisReply('ผลวิเคราะห์ไฟล์'), 'ผลวิเคราะห์ไฟล์')
  assert.equal(formatAutoAnalysisReply('', 'คำตอบจาก AI'), 'คำตอบจาก AI')
  assert.equal(
    formatAutoAnalysisReply('ผลวิเคราะห์ไฟล์', 'คำตอบจาก AI'),
    'ผลวิเคราะห์ไฟล์\n\n---\n\nคำตอบจาก AI',
  )
})
