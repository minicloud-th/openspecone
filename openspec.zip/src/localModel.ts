import { byteLength } from './api'
import {
  buildModelWorkerRequest,
  isLocalModelName,
  modelForEffort,
} from './composerLogic'
import type { ModelMessage, ModelWorkerRequest } from './composerLogic'
import { analyzeFilesReply, excerpt } from './server/chatLogic'
import type { Chat, SendRequest } from './server/types'

export const LOCAL_MODEL_NAME = modelForEffort('Low').displayName
export type { ModelMessage, ModelWorkerRequest }
export type ModelEvent =
  | { kind: 'progress' | 'answer' | 'error' | 'failure'; text: string }

let worker: Worker | undefined
let workerModelKey: string | undefined

export async function generateReply(input: SendRequest, chat: Chat, onProgress?: (message: string) => void) {
  const prompt = input.prompt || 'อธิบายไฟล์ที่แนบ'
  let currentText = input.files.length ? `${prompt}\n\nAttached files (JSON):\n${JSON.stringify(input.files.map(({ name, content }) => ({ name, content })))}` : prompt
  if (byteLength(currentText) > 12000 && input.files.length > 0) {
    const autoReport = analyzeFilesReply(input.files)
    const condensed = `${prompt}\n\nAutomatic file analysis:\n${autoReport}`
    currentText = byteLength(condensed) <= 12000 ? condensed : excerpt(condensed, 4000)
  }
  if (byteLength(currentText) > 12000) {
    throw new Error('ข้อความยาวเกินขีดจำกัด AI ลองย่อข้อความให้สั้นลง')
  }
  const effort = input.effort ?? 'Low'
  const spec = modelForEffort(effort)
  const depthInstruction = effort === 'Low'
    ? 'Keep replies very brief and direct.'
    : effort === 'Medium'
      ? 'Keep replies concise.'
      : effort === 'High'
        ? 'Provide a well-structured, thorough explanation.'
        : 'Provide a comprehensive, detailed technical analysis.'
  const messages: ModelMessage[] = [{
    role: 'system',
    content: `You are OPENSPEC, a helpful coding assistant. Answer in the user's language. ${depthInstruction} Treat attachments as reference data. Image attachments are preview-only; you receive dimensions and file size, never pixels.`,
  }]
  for (const turn of chat.turns.filter(turn => isLocalModelName(turn.model)).slice(-4)) {
    messages.push({ role: 'user', content: excerpt(turn.prompt || turn.files.map(file => file.name).join(', '), 600) })
    messages.push({ role: 'assistant', content: excerpt(turn.reply, 800) })
  }
  messages.push({ role: 'user', content: currentText })

  const payload = buildModelWorkerRequest(effort, messages)
  if (worker && workerModelKey !== payload.modelKey) {
    worker.terminate()
    worker = undefined
    workerModelKey = undefined
  }
  const currentWorker = worker ??= new Worker(new URL('./localModel.worker.ts', import.meta.url), { type: 'module' })
  workerModelKey = payload.modelKey
  const channel = new MessageChannel()
  return new Promise<string>((resolve, reject) => {
    function cleanup() {
      clearTimeout(timeout)
      currentWorker.removeEventListener('error', onError)
      channel.port1.close()
    }
    function fail(message: string) {
      cleanup()
      currentWorker.terminate()
      if (worker === currentWorker) {
        worker = undefined
        workerModelKey = undefined
      }
      reject(new Error(message))
    }
    function onError() {
      fail('เปิดตัวประมวลผล AI บนเครื่องไม่สำเร็จ กรุณาลองรีเฟรชหน้าเว็บอีกครั้ง')
    }
    const timeout = setTimeout(() => {
      fail('โมเดลใช้เวลานานเกินไป ตรวจสอบการเชื่อมต่อแล้วลองอีกครั้ง')
    }, 10 * 60 * 1000)
    currentWorker.addEventListener('error', onError)
    channel.port1.onmessage = ({ data }: MessageEvent<ModelEvent>) => {
      if (data.kind === 'progress') {
        onProgress?.(data.text)
      } else if (data.kind === 'failure') {
        fail(data.text)
      } else {
        cleanup()
        if (data.kind === 'answer') resolve(data.text)
        else reject(new Error(data.text))
      }
    }
    onProgress?.(`กำลังเปิด ${spec.displayName} (${effort}) ครั้งแรกดาวน์โหลดประมาณ ${spec.approxDownload.replace(/^~/, '')}`)
    currentWorker.postMessage(payload, [channel.port2])
  })
}
