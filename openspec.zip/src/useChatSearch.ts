import { useEffect, useState } from 'react'
import { api, errorMessage } from './api'
import type { ChatSearchResult, ChatSummary } from './api'

export function useChatSearch(text: string, chats: ChatSummary[], enabled = true) {
  const query = text.trim()
  const [search, setSearch] = useState<{ query: string; results: ChatSearchResult[]; error?: string }>()
  useEffect(() => {
    if (!enabled || !query) return
    let cancelled = false
    const timer = window.setTimeout(() => {
      void api<ChatSearchResult[]>('/chats/search', { query }).then(
        results => { if (!cancelled) setSearch({ query, results }) },
        error => { if (!cancelled) setSearch({ query, results: [], error: errorMessage(error) }) },
      )
    }, 180)
    return () => {
      cancelled = true
      window.clearTimeout(timer)
    }
  }, [enabled, query, chats])
  const current = search?.query === query ? search : undefined
  const results: ChatSearchResult[] = query ? current?.results ?? [] : chats
  return { results, error: current?.error, pending: Boolean(query && enabled && !current) }
}
