export const SECTIONS = ['home', 'chats', 'subscription', 'plugins', 'ideas', 'dashboard'] as const
export type RailSection = typeof SECTIONS[number]
export type WorkspaceRoute = { section: RailSection; item?: string }
export type Navigate = (section: RailSection, item?: string) => void

export function routeFromHash(hash: string): WorkspaceRoute {
  const [section] = hash.slice(1).split('/')
  if (section === 'search') return { section: 'chats' }
  if (section === 'projects') return { section: 'subscription' }
  if (!(SECTIONS as readonly string[]).includes(section)) return { section: 'home' }
  return { section: section as RailSection }
}

export function routeHash({ section, item }: WorkspaceRoute) {
  return '#' + section + (item ? '/' + item : '')
}
