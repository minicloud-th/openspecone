import { useEffect, useRef, useState } from 'react'
import { motion } from 'motion/react'
import { signInWithPopup } from 'firebase/auth'
import { ModernLoginSignup } from '@/components/ui/modern-login-signup'
import { errorMessage } from './api'
import type { AuthUser } from './api'
import {
  accountFromFirebase,
  firebaseAuth,
  firebaseErrorMessage,
  githubProvider,
  googleProvider,
} from './firebase'
import { IOS_LIQUID_SPRING } from './motion'

export function LoginScreen({
  onAuthenticated,
}: {
  onAuthenticated(result: AuthUser, token?: string): void
}) {
  const [busyProvider, setBusyProvider] = useState<'google' | 'github' | 'discord' | null>(null)
  const [error, setError] = useState('')
  const popupRef = useRef<Window | null>(null)
  const pollTimerRef = useRef<number | null>(null)

  const clearPopupWatch = () => {
    if (pollTimerRef.current !== null) {
      window.clearInterval(pollTimerRef.current)
      pollTimerRef.current = null
    }
    popupRef.current = null
  }

  useEffect(() => () => clearPopupWatch(), [])

  useEffect(() => {
    const handleMessage = async (event: MessageEvent) => {
      const origin = event.origin
      if (
        origin !== window.location.origin &&
        !origin.endsWith('.run.app') &&
        !origin.includes('localhost')
      ) {
        return
      }

      const payload = event.data as
        | { type?: string; ticket?: string; error?: string }
        | undefined
      if (!payload || typeof payload.type !== 'string') return

      if (payload.type === 'DISCORD_OAUTH_ERROR') {
        clearPopupWatch()
        setBusyProvider(null)
        setError(payload.error || 'เชื่อมต่อ Discord ไม่สำเร็จ')
        return
      }

      if (payload.type === 'DISCORD_OAUTH_SUCCESS' && payload.ticket) {
        clearPopupWatch()
        try {
          const claimRes = await fetch('/api/auth/discord/claim', {
            method: 'POST',
            credentials: 'include',
            headers: {
              'Content-Type': 'application/json',
              'X-Requested-With': 'OPENSPEC',
            },
            body: JSON.stringify({ ticket: payload.ticket }),
          })
          const claimData = (await claimRes.json()) as {
            user?: AuthUser
            token?: string
            error?: string
          }
          if (!claimRes.ok || !claimData.user) {
            throw new Error(claimData.error || 'ยืนยันเซสชัน Discord ไม่สำเร็จ')
          }
          onAuthenticated(claimData.user, claimData.token)
        } catch (failure) {
          setError(errorMessage(failure))
        } finally {
          setBusyProvider(null)
        }
      }
    }

    window.addEventListener('message', handleMessage)
    return () => window.removeEventListener('message', handleMessage)
  }, [onAuthenticated])

  async function signInWithProvider(providerId: 'google' | 'github') {
    if (busyProvider) return
    setError('')
    if (!firebaseAuth) {
      setError('เชื่อมต่อ Firebase Authentication ไม่ได้ในขณะนี้')
      return
    }

    setBusyProvider(providerId)
    try {
      const provider = providerId === 'google' ? googleProvider : githubProvider
      const credential = await signInWithPopup(firebaseAuth, provider)
      onAuthenticated(accountFromFirebase(credential.user, providerId))
    } catch (failure) {
      if (typeof failure === 'object' && failure !== null && 'code' in failure) {
        setError(firebaseErrorMessage(failure))
      } else {
        setError(errorMessage(failure))
      }
    } finally {
      setBusyProvider(null)
    }
  }

  async function signInWithDiscord() {
    if (busyProvider) return
    setError('')
    setBusyProvider('discord')
    try {
      const response = await fetch('/api/auth/discord/url', { credentials: 'include' })
      const data = (await response.json()) as { url?: string; error?: string }
      if (!response.ok || !data.url) {
        throw new Error(data.error || 'สร้างลิงก์เข้าสู่ระบบ Discord ไม่สำเร็จ')
      }

      const authWindow = window.open(
        data.url,
        'discord_oauth_popup',
        'width=560,height=740,noopener=no',
      )
      if (!authWindow) {
        setBusyProvider(null)
        setError('เบราว์เซอร์บล็อกหน้าต่างป๊อปอัป กรุณาอนุญาตป๊อปอัปแล้วลองอีกครั้ง')
        return
      }

      clearPopupWatch()
      popupRef.current = authWindow
      pollTimerRef.current = window.setInterval(() => {
        if (popupRef.current && popupRef.current.closed) {
          clearPopupWatch()
          setBusyProvider(current => (current === 'discord' ? null : current))
        }
      }, 450)
    } catch (failure) {
      clearPopupWatch()
      setBusyProvider(null)
      setError(errorMessage(failure))
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={IOS_LIQUID_SPRING}
    >
      <ModernLoginSignup
        showEmailForm={false}
        showModeSwitch={false}
        showGoogle
        showGitHub
        showDiscord
        showApple={false}
        onGoogleAuth={() => signInWithProvider('google')}
        onGitHubAuth={() => signInWithProvider('github')}
        onDiscordAuth={() => signInWithDiscord()}
        busyProvider={busyProvider}
        error={error}
        brandLogo={
          <div className="mb-3 flex size-11 items-center justify-center rounded-full border border-[#333] bg-[#111] text-white">
            <span className="openspec-site-icon" aria-hidden="true" />
          </div>
        }
        brandName="OPENSPEC"
        titleSignIn="Welcome to OPENSPEC"
        subtitleSignIn="เลือกผู้ให้บริการเพื่อเข้าสู่ Workspace"
        googleLabelSignIn={
          busyProvider === 'google'
            ? 'กำลังเชื่อมต่อ Google...'
            : 'ลงชื่อเข้าใช้ด้วย Google'
        }
        githubLabelSignIn={
          busyProvider === 'github'
            ? 'กำลังเชื่อมต่อ GitHub...'
            : 'ลงชื่อเข้าใช้ด้วย GitHub'
        }
        discordLabelSignIn={
          busyProvider === 'discord'
            ? 'กำลังเชื่อมต่อ Discord...'
            : 'ลงชื่อเข้าใช้ด้วย Discord'
        }
        termsHref="/terms"
        privacyHref="/privacy"
        legalContent={
          <>
            เมื่อดำเนินการต่อ คุณยอมรับ{' '}
            <a
              href="/terms"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#888] underline underline-offset-2 hover:text-white"
            >
              ข้อกำหนดการใช้งาน
            </a>{' '}
            และรับทราบ{' '}
            <a
              href="/privacy"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#888] underline underline-offset-2 hover:text-white"
            >
              นโยบายความเป็นส่วนตัว
            </a>{' '}
            ของ OPENSPEC
          </>
        }
      />
    </motion.div>
  )
}
