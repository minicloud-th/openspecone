import type { ReactNode } from 'react'
import { motion } from 'motion/react'
import { Popover } from 'radix-ui'
import type { DashboardStats } from './api'
import {
  ChevronRight,
  CreditCard,
  Home,
  Lightbulb,
  MessageSquare,
  Plug,
} from './icons'
import { IOS_SNAPPY_SPRING } from './motion'
import { UsageIcon } from './UsageIcon'

import type { RailSection } from './navigation'

const MID_ITEMS: {
  id: RailSection
  title: string
  icon: typeof Home
}[] = [
  { id: 'home', title: 'หน้าหลัก', icon: Home },
  { id: 'chats', title: 'แชตทั้งหมด', icon: MessageSquare },
  { id: 'subscription', title: 'Subscription', icon: CreditCard },
  { id: 'plugins', title: 'ปลั๊กอิน', icon: Plug },
  { id: 'ideas', title: 'เทมเพลตคำสั่ง', icon: Lightbulb },
]

type RailProps = {
  section: RailSection
  chatCount: number
  stats?: DashboardStats
  busy: boolean
  onSelectSection(section: RailSection): void
  accountMenu: ReactNode
}

function remainingCapacity(used = 0, limit = 0) {
  return limit > 0 ? Math.min(100, Math.max(0, 100 * (limit - used) / limit)) : 0
}

function formatRemainingPercent(remaining: number) {
  return remaining > 0 && remaining < 1 ? '<1%' : Math.floor(remaining) + '%'
}

export function Rail({
  section,
  chatCount,
  stats,
  busy,
  onSelectSection,
  accountMenu,
}: RailProps) {
  const ready = Boolean(stats)
  const storageRemaining = remainingCapacity(stats?.storageBytes, stats?.maxStorageBytes)
  const chatRemaining = remainingCapacity(stats?.totalChats, stats?.chatLimit)
  const storageLabel = formatRemainingPercent(storageRemaining)
  const chatLabel = formatRemainingPercent(chatRemaining)

  function renderItem(item: (typeof MID_ITEMS)[number]) {
    const ItemIcon = item.icon
    const active = section === item.id
    return (
      <motion.button
        key={item.id}
        type="button"
        className={'oc-rb' + (active ? ' on' : '')}
        title={item.title}
        aria-label={item.title}
        aria-current={active ? 'page' : undefined}
        disabled={!ready || busy}
        whileTap={!ready || busy ? undefined : { scale: 0.88 }}
        transition={IOS_SNAPPY_SPRING}
        onClick={() => onSelectSection(item.id)}
      >
        {active && (
          <motion.span
            layoutId="rail-active-pill"
            className="oc-rb-bg"
            transition={IOS_SNAPPY_SPRING}
            aria-hidden="true"
          />
        )}
        <ItemIcon size={20} className="relative z-1" />
        {item.id === 'chats' && chatCount > 0 && (
          <span className="oc-bd tabular-nums">{chatCount}</span>
        )}
      </motion.button>
    )
  }

  return (
    <nav className="oc-rail" aria-label="แถบนำทางหลัก">
      <span className="oc-rail-brand">
        <span className="openspec-site-icon" role="img" aria-label="OPENSPEC" />
      </span>

      <div className="oc-rail-mid">
        {MID_ITEMS.map(renderItem)}
      </div>

      <div className="oc-rail-bot">
        <Popover.Root>
          <Popover.Trigger asChild>
            <motion.button type="button"
              className={'oc-rb usage-button' + (section === 'dashboard' ? ' on' : '')}
              aria-label="การใช้งาน"
              title={ready ? `พื้นที่จัดเก็บเหลือ ${storageLabel} · โควตาแชตเหลือ ${chatLabel}` : 'การใช้งาน'}
              disabled={!ready || busy}
              whileTap={!ready || busy ? undefined : { scale: 0.9 }}
              transition={IOS_SNAPPY_SPRING}
            >
              <UsageIcon storage={storageRemaining} chats={chatRemaining} />
            </motion.button>
          </Popover.Trigger>
          <Popover.Portal>
            <Popover.Content className="usage-popover" aria-label="สรุปการใช้งาน Workspace"
              side="right" align="end" sideOffset={11} collisionPadding={8}>
              <p className="usage-heading">การใช้งาน Workspace</p>
              <dl className="usage-rows">
                <div><dt>พื้นที่จัดเก็บ</dt><dd>เหลือ {storageLabel}</dd></div>
                <div><dt>แชตที่ใช้งานอยู่</dt><dd>เหลือ {chatLabel}</dd></div>
              </dl>
              <Popover.Close asChild>
                <button type="button" className="usage-manage" onClick={() => onSelectSection('dashboard')}>
                  จัดการการใช้งาน <ChevronRight size={15} />
                </button>
              </Popover.Close>
            </Popover.Content>
          </Popover.Portal>
        </Popover.Root>
        {accountMenu}
      </div>
    </nav>
  )
}
