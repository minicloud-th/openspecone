export async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text)
      return true
    }
  } catch {
    // Embedded browsers may require the selection-based fallback.
  }

  const previousFocus = document.activeElement
  const selection = document.getSelection()
  const ranges = selection && Array.from({ length: selection.rangeCount }, (_, i) => selection.getRangeAt(i))
  const field = document.createElement('textarea')
  field.value = text
  field.readOnly = true
  field.style.position = 'fixed'
  field.style.opacity = '0'
  document.body.appendChild(field)
  try {
    field.select()
    return document.execCommand('copy')
  } catch {
    return false
  } finally {
    field.remove()
    if (previousFocus instanceof HTMLElement) previousFocus.focus({ preventScroll: true })
    if (selection && ranges) {
      selection.removeAllRanges()
      for (const range of ranges) selection.addRange(range)
    }
  }
}
