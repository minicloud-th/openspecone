"use client";

import * as React from "react";
import * as THREE from "three";
import { motion, useReducedMotion } from "motion/react";
import { Eye, EyeOff } from "lucide-react";

import { cn } from "@/lib/utils";
import { IOS_LIQUID_SPRING } from "@/src/motion";

export type ModernLoginSignupMode = "signin" | "signup";

export interface ModernLoginSignupSubmitPayload {
  mode: ModernLoginSignupMode;
  name: string;
  email: string;
  password: string;
}

export interface ModernLoginSignupProps {
  className?: string;
  mode?: ModernLoginSignupMode;
  defaultMode?: ModernLoginSignupMode;
  onModeChange?: (mode: ModernLoginSignupMode) => void;
  name?: string;
  onNameChange?: (name: string) => void;
  email?: string;
  onEmailChange?: (email: string) => void;
  password?: string;
  onPasswordChange?: (password: string) => void;
  showPasswordField?: boolean;
  showNameFieldOnSignUp?: boolean;
  showEmailForm?: boolean;
  showModeSwitch?: boolean;
  onSubmitEmail?: (payload: ModernLoginSignupSubmitPayload) => void | Promise<void>;
  onForgotPassword?: () => void | Promise<void>;
  onGoogleAuth?: () => void | Promise<void>;
  onGitHubAuth?: () => void | Promise<void>;
  onDiscordAuth?: () => void | Promise<void>;
  onAppleAuth?: () => void | Promise<void>;
  showGoogle?: boolean;
  showGitHub?: boolean;
  showDiscord?: boolean;
  showApple?: boolean;
  busyProvider?: "google" | "github" | "discord" | "apple" | "email" | null;
  error?: string;
  info?: string;
  brandLogo?: React.ReactNode;
  brandName?: string;
  titleSignIn?: string;
  titleSignUp?: string;
  subtitleSignIn?: string;
  subtitleSignUp?: string;
  namePlaceholder?: string;
  emailPlaceholder?: string;
  passwordPlaceholderSignIn?: string;
  passwordPlaceholderSignUp?: string;
  emailCtaSignIn?: string;
  emailCtaSignUp?: string;
  googleLabelSignIn?: string;
  googleLabelSignUp?: string;
  githubLabelSignIn?: string;
  githubLabelSignUp?: string;
  discordLabelSignIn?: string;
  discordLabelSignUp?: string;
  appleLabelSignIn?: string;
  appleLabelSignUp?: string;
  forgotPasswordLabel?: string;
  switchToSignUpText?: string;
  switchToSignUpAction?: string;
  switchToSignInText?: string;
  switchToSignInAction?: string;
  termsHref?: string;
  privacyHref?: string;
  legalContent?: React.ReactNode;
}

const VERTEX_SHADER = `
  precision mediump float;
  uniform vec2 u_resolution;
  out vec2 fragCoord;
  void main() {
    gl_Position = vec4(position, 1.0);
    fragCoord = (position.xy + 1.0) * 0.5 * u_resolution;
    fragCoord.y = u_resolution.y - fragCoord.y;
  }
`;

const FRAGMENT_SHADER = `
  precision mediump float;
  in vec2 fragCoord;

  uniform float u_time;
  uniform float u_opacities[10];
  uniform vec3 u_colors[6];
  uniform float u_total_size;
  uniform float u_dot_size;
  uniform vec2 u_resolution;
  uniform int u_reverse;

  out vec4 fragColor;

  float PHI = 1.61803398874989484820459;
  float random(vec2 xy) {
    return fract(tan(distance(xy * PHI, xy) * 0.5) * xy.x);
  }

  void main() {
    vec2 st = fragCoord.xy;
    st.x -= abs(floor((mod(u_resolution.x, u_total_size) - u_dot_size) * 0.5));
    st.y -= abs(floor((mod(u_resolution.y, u_total_size) - u_dot_size) * 0.5));

    float opacity = step(0.0, st.x) * step(0.0, st.y);

    vec2 st2 = vec2(int(st.x / u_total_size), int(st.y / u_total_size));

    float frequency = 5.0;
    float show_offset = random(st2);
    float rand = random(st2 * floor((u_time / frequency) + show_offset + frequency));
    opacity *= u_opacities[int(rand * 10.0)];
    opacity *= 1.0 - step(u_dot_size / u_total_size, fract(st.x / u_total_size));
    opacity *= 1.0 - step(u_dot_size / u_total_size, fract(st.y / u_total_size));

    vec3 color = u_colors[int(show_offset * 6.0)];

    float animation_speed_factor = 3.0;
    vec2 center_grid = u_resolution / 2.0 / u_total_size;
    float dist_from_center = distance(center_grid, st2);

    float timing_offset_intro = dist_from_center * 0.01 + (random(st2) * 0.15);

    float current_timing_offset = timing_offset_intro;
    opacity *= step(current_timing_offset, u_time * animation_speed_factor);
    opacity *= clamp((1.0 - step(current_timing_offset + 0.1, u_time * animation_speed_factor)) * 1.25, 1.0, 1.25);

    fragColor = vec4(color, opacity);
    fragColor.rgb *= fragColor.a;
  }
`;

function detectSoftwareWebGL(): boolean {
  try {
    const probeCanvas = document.createElement("canvas");
    const gl = probeCanvas.getContext("webgl2");
    if (!gl) return true;
    const ext = gl.getExtension("WEBGL_debug_renderer_info");
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension("WEBGL_lose_context")?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export function ModernLoginSignup({
  className,
  mode: controlledMode,
  defaultMode = "signin",
  onModeChange,
  name: controlledName,
  onNameChange,
  email: controlledEmail,
  onEmailChange,
  password: controlledPassword,
  onPasswordChange,
  showPasswordField = false,
  showNameFieldOnSignUp = true,
  showEmailForm = true,
  showModeSwitch = true,
  onSubmitEmail,
  onForgotPassword,
  onGoogleAuth,
  onGitHubAuth,
  onDiscordAuth,
  onAppleAuth,
  showGoogle = true,
  showGitHub = true,
  showDiscord = false,
  showApple = true,
  busyProvider = null,
  error,
  info,
  brandLogo,
  brandName,
  titleSignIn = "Sign in to Account",
  titleSignUp = "Sign up for Account",
  subtitleSignIn = "Sign in to your Account.",
  subtitleSignUp = "Create a new account to get started.",
  namePlaceholder = "Full Name",
  emailPlaceholder = "name@work-email.com",
  passwordPlaceholderSignIn = "Password",
  passwordPlaceholderSignUp = "Password (at least 8 characters)",
  emailCtaSignIn = "Continue with Email",
  emailCtaSignUp = "Sign Up with Email",
  googleLabelSignIn = "Continue with Google",
  googleLabelSignUp = "Sign up with Google",
  githubLabelSignIn = "Continue with GitHub",
  githubLabelSignUp = "Sign up with GitHub",
  discordLabelSignIn = "Continue with Discord",
  discordLabelSignUp = "Sign up with Discord",
  appleLabelSignIn = "Continue with Apple",
  appleLabelSignUp = "Sign up with Apple",
  forgotPasswordLabel = "Forgot password?",
  switchToSignUpText = "Don't have an account?",
  switchToSignUpAction = "Sign Up",
  switchToSignInText = "Already have an account?",
  switchToSignInAction = "Sign In",
  termsHref = "/terms",
  privacyHref = "/privacy",
  legalContent,
}: ModernLoginSignupProps) {
  const canvasRef = React.useRef<HTMLCanvasElement>(null);
  const reducedMotion = useReducedMotion() === true;
  const [innerMode, setInnerMode] = React.useState<ModernLoginSignupMode>(defaultMode);
  const [innerName, setInnerName] = React.useState("");
  const [innerEmail, setInnerEmail] = React.useState("");
  const [innerPassword, setInnerPassword] = React.useState("");
  const [showPassword, setShowPassword] = React.useState(false);

  const mode = controlledMode ?? innerMode;
  const isLogin = mode === "signin";
  const name = controlledName ?? innerName;
  const email = controlledEmail ?? innerEmail;
  const password = controlledPassword ?? innerPassword;

  const setMode = (next: ModernLoginSignupMode) => {
    if (controlledMode === undefined) setInnerMode(next);
    onModeChange?.(next);
  };

  const setName = (next: string) => {
    if (controlledName === undefined) setInnerName(next);
    onNameChange?.(next);
  };

  const setEmail = (next: string) => {
    if (controlledEmail === undefined) setInnerEmail(next);
    onEmailChange?.(next);
  };

  const setPassword = (next: string) => {
    if (controlledPassword === undefined) setInnerPassword(next);
    onPasswordChange?.(next);
  };

  React.useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    let active = true;
    let animationId = 0;
    let timeoutId = 0;
    let renderer: THREE.WebGLRenderer | null = null;
    let geometry: THREE.PlaneGeometry | null = null;
    let material: THREE.ShaderMaterial | null = null;

    const isSoftwareGl = detectSoftwareWebGL();
    const dpr = isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2);

    try {
      renderer = new THREE.WebGLRenderer({
        canvas,
        alpha: true,
        antialias: false,
        powerPreference: "high-performance",
      });
    } catch {
      return;
    }

    renderer.setPixelRatio(dpr);
    renderer.setSize(window.innerWidth, window.innerHeight);

    const scene = new THREE.Scene();
    const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);

    const uniforms = {
      u_time: { value: 0 },
      u_resolution: {
        value: new THREE.Vector2(window.innerWidth * 2, window.innerHeight * 2),
      },
      u_opacities: {
        value: [0.3, 0.3, 0.3, 0.5, 0.5, 0.5, 0.8, 0.8, 0.8, 1.0],
      },
      u_colors: {
        value: [
          new THREE.Vector3(1, 1, 1),
          new THREE.Vector3(1, 1, 1),
          new THREE.Vector3(1, 1, 1),
          new THREE.Vector3(1, 1, 1),
          new THREE.Vector3(1, 1, 1),
          new THREE.Vector3(1, 1, 1),
        ],
      },
      u_total_size: { value: 20.0 },
      u_dot_size: { value: 6.0 },
      u_reverse: { value: 0 },
    };

    material = new THREE.ShaderMaterial({
      vertexShader: VERTEX_SHADER,
      fragmentShader: FRAGMENT_SHADER,
      uniforms,
      glslVersion: THREE.GLSL3,
      blending: THREE.CustomBlending,
      blendSrc: THREE.SrcAlphaFactor,
      blendDst: THREE.OneFactor,
      transparent: true,
    });

    geometry = new THREE.PlaneGeometry(2, 2);
    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    const startTime = performance.now();

    const afterDraw = (cb: () => void) => {
      if (!renderer || !active) return;
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (typeof gl.fenceSync === "function") {
        const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        gl.flush();
        const poll = () => {
          if (!active) {
            if (sync) gl.deleteSync(sync);
            return;
          }
          const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
          if (state === gl.UNSIGNALED) {
            timeoutId = window.setTimeout(poll, 5);
          } else {
            if (sync) gl.deleteSync(sync);
            timeoutId = window.setTimeout(cb, 80);
          }
        };
        timeoutId = window.setTimeout(poll, 5);
      } else {
        timeoutId = window.setTimeout(cb, 80);
      }
    };

    const animate = () => {
      if (!active || !renderer) return;
      uniforms.u_time.value = (performance.now() - startTime) / 1000.0;
      renderer.render(scene, camera);
      if (isSoftwareGl) {
        afterDraw(animate);
      } else {
        animationId = requestAnimationFrame(animate);
      }
    };

    animate();

    const handleResize = () => {
      if (!renderer || !active) return;
      renderer.setSize(window.innerWidth, window.innerHeight);
      uniforms.u_resolution.value.set(
        window.innerWidth * 2,
        window.innerHeight * 2,
      );
    };
    window.addEventListener("resize", handleResize);

    return () => {
      active = false;
      window.removeEventListener("resize", handleResize);
      if (animationId) cancelAnimationFrame(animationId);
      if (timeoutId) window.clearTimeout(timeoutId);
      geometry?.dispose();
      material?.dispose();
      renderer?.dispose();
    };
  }, []);

  const handleFormSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (busyProvider) return;
    void onSubmitEmail?.({ mode, name, email, password });
  };

  const disabled = busyProvider !== null;

  const googleIcon = (
    <svg viewBox="0 0 24 24" className="size-4 shrink-0" aria-hidden="true">
      <path
        fill="#4285F4"
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
      />
      <path
        fill="#34A853"
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
      />
      <path
        fill="#FBBC05"
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
      />
      <path
        fill="#EA4335"
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
      />
    </svg>
  );

  const githubIcon = (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      className="size-4 shrink-0"
      aria-hidden="true"
    >
      <path d="M12 2C6.477 2 2 6.477 2 12c0 4.42 2.865 8.166 6.839 9.489.5.092.682-.217.682-.482 0-.237-.008-.866-.013-1.699-2.782.603-3.369-1.34-3.369-1.34-.454-1.156-1.11-1.462-1.11-1.462-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.831.092-.646.35-1.086.636-1.336-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.578 9.578 0 0112 6.836c.85.004 1.705.114 2.504.336 1.909-1.294 2.747-1.025 2.747-1.025.546 1.379.203 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.577.688.48C19.138 20.161 22 16.416 22 12c0-5.523-4.477-10-10-10z" />
    </svg>
  );

  const discordIcon = (
    <svg
      viewBox="0 0 24 24"
      fill="#5865F2"
      className="size-4 shrink-0"
      aria-hidden="true"
    >
      <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
    </svg>
  );

  const appleIcon = (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      className="size-4 shrink-0"
      aria-hidden="true"
    >
      <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.04 2.26-.79 3.59-.76 1.56.04 2.88.75 3.65 1.89-3.08 1.75-2.58 5.61.35 6.75-1.01 2.37-2.39 4.39-4.29 4.29zM12.03 7.25c-.15-2.23 1.66-4.07 3.72-4.25.36 2.38-1.92 4.34-3.72 4.25z" />
    </svg>
  );

  const renderedLogo = brandLogo ?? (
    <div className="mb-3 flex size-11 items-center justify-center rounded-full border border-[#333] bg-[#111] text-[1.15rem] font-bold text-white">
      JS
    </div>
  );

  const socialBtnClass =
    "flex w-full items-center justify-center gap-2 rounded-[6px] border border-[#333]/90 bg-white/[0.02] px-3 py-[0.65rem] text-[0.875rem] font-medium text-white transition-all duration-200 ease-[cubic-bezier(0.22,1,0.36,1)] hover:border-[#52525b] hover:bg-white/[0.06] active:scale-[0.985] disabled:cursor-default disabled:opacity-60";

  const inputClass =
    "w-full rounded-[6px] border border-[#333] bg-black px-[0.85rem] py-[0.65rem] text-[0.875rem] text-white placeholder:text-[#737373] outline-none transition-colors focus:border-[#666]";

  return (
    <div
      className={cn(
        "relative flex min-h-screen w-full items-center justify-center overflow-x-hidden overflow-y-auto bg-black px-4 py-8 text-white",
        className,
      )}
    >
      {/* WebGL Dot-matrix Canvas */}
      <canvas
        ref={canvasRef}
        data-testid="auth-dot-canvas"
        className="pointer-events-none fixed inset-0 z-0 size-full"
        aria-hidden="true"
      />

      {/* Radial Vignette */}
      <div
        className="pointer-events-none fixed inset-0 z-[1]"
        style={{
          background:
            "radial-gradient(circle at center, rgba(0,0,0,0.75) 0%, rgba(0,0,0,0) 100%)",
        }}
        aria-hidden="true"
      />

      {/* Modal Card */}
      <main className="relative z-[2] flex w-full max-w-[400px] flex-col items-center">
        <motion.section
          aria-labelledby="auth-card-heading"
          initial={reducedMotion ? false : { opacity: 0, y: 18, scale: 0.95, filter: "blur(6px)" }}
          animate={{ opacity: 1, y: 0, scale: 1, filter: "blur(0px)" }}
          transition={IOS_LIQUID_SPRING}
          className="flex w-full flex-col items-center rounded-xl border border-white/12 bg-[#121212]/88 p-8 shadow-[inset_0_1px_0_rgba(255,255,255,0.08),0_18px_50px_rgba(0,0,0,0.85)] backdrop-blur-2xl"
        >
          <div className="flex w-full max-w-[360px] flex-col items-center text-center">
            {renderedLogo}

            {brandName && (
              <span className="mb-2 text-[11px] font-semibold tracking-[0.18em] text-[#999] uppercase">
                {brandName}
              </span>
            )}

            <h1
              id="auth-card-heading"
              className="mb-1 text-[1.35rem] font-semibold tracking-[-0.025em] text-white"
            >
              {isLogin ? titleSignIn : titleSignUp}
            </h1>
            <p className="mb-[0.85rem] text-[0.85rem] leading-normal text-[#888]">
              {isLogin ? subtitleSignIn : subtitleSignUp}
            </p>

            {showEmailForm && (
              <form
                onSubmit={handleFormSubmit}
                noValidate
                className="flex w-full flex-col gap-[0.65rem]"
              >
                {!isLogin && showNameFieldOnSignUp && (
                  <div>
                    <label htmlFor="auth-full-name" className="sr-only">
                      {namePlaceholder}
                    </label>
                    <input
                      id="auth-full-name"
                      type="text"
                      className={inputClass}
                      placeholder={namePlaceholder}
                      maxLength={40}
                      autoComplete="name"
                      disabled={disabled}
                      value={name}
                      onChange={(event) => setName(event.target.value)}
                    />
                  </div>
                )}

                <div>
                  <label htmlFor="auth-email" className="sr-only">
                    {emailPlaceholder}
                  </label>
                  <input
                    id="auth-email"
                    type="email"
                    className={inputClass}
                    placeholder={emailPlaceholder}
                    maxLength={120}
                    autoComplete="email"
                    disabled={disabled}
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                    required
                  />
                </div>

                {showPasswordField && (
                  <div className="relative">
                    <label htmlFor="auth-password" className="sr-only">
                      {isLogin
                        ? passwordPlaceholderSignIn
                        : passwordPlaceholderSignUp}
                    </label>
                    <input
                      id="auth-password"
                      type={showPassword ? "text" : "password"}
                      className={cn(inputClass, "pr-10")}
                      placeholder={
                        isLogin
                          ? passwordPlaceholderSignIn
                          : passwordPlaceholderSignUp
                      }
                      maxLength={128}
                      autoComplete={isLogin ? "current-password" : "new-password"}
                      disabled={disabled}
                      value={password}
                      onChange={(event) => setPassword(event.target.value)}
                      required
                    />
                    <button
                      type="button"
                      aria-label={showPassword ? "ซ่อนรหัสผ่าน" : "แสดงรหัสผ่าน"}
                      disabled={disabled}
                      onClick={() => setShowPassword((prev) => !prev)}
                      className="absolute top-1/2 right-2.5 flex size-7 -translate-y-1/2 items-center justify-center rounded text-[#888] transition-colors hover:text-white disabled:opacity-50"
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                )}

                {isLogin && onForgotPassword && (
                  <div className="flex justify-end">
                    <button
                      type="button"
                      disabled={disabled}
                      onClick={() => void onForgotPassword()}
                      className="text-[0.78rem] font-medium text-[#888] transition-colors hover:text-white disabled:opacity-50"
                    >
                      {forgotPasswordLabel}
                    </button>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={disabled}
                  className="w-full rounded-[6px] border-0 bg-[#ededed] px-3 py-[0.65rem] text-[0.875rem] font-medium text-black transition-colors hover:bg-white disabled:cursor-default disabled:opacity-60"
                >
                  {isLogin ? emailCtaSignIn : emailCtaSignUp}
                </button>
              </form>
            )}

            {(showGoogle || showGitHub || showDiscord || showApple) && (
              <>
                {showEmailForm && (
                  <div className="my-[0.85rem] h-px w-full bg-[#222]" />
                )}

                <div className={cn("flex w-full flex-col gap-[0.55rem]", !showEmailForm && "mt-1")}>
                  {showGoogle && (
                    <button
                      type="button"
                      disabled={disabled}
                      onClick={() => void onGoogleAuth?.()}
                      className={socialBtnClass}
                    >
                      {googleIcon}
                      <span>
                        {isLogin ? googleLabelSignIn : googleLabelSignUp}
                      </span>
                    </button>
                  )}

                  {showGitHub && (
                    <button
                      type="button"
                      disabled={disabled}
                      onClick={() => void onGitHubAuth?.()}
                      className={socialBtnClass}
                    >
                      {githubIcon}
                      <span>
                        {isLogin ? githubLabelSignIn : githubLabelSignUp}
                      </span>
                    </button>
                  )}

                  {showDiscord && (
                    <button
                      type="button"
                      disabled={disabled}
                      onClick={() => void onDiscordAuth?.()}
                      className={socialBtnClass}
                    >
                      {discordIcon}
                      <span>
                        {isLogin ? discordLabelSignIn : discordLabelSignUp}
                      </span>
                    </button>
                  )}

                  {showApple && (
                    <button
                      type="button"
                      disabled={disabled}
                      onClick={() => void onAppleAuth?.()}
                      className={socialBtnClass}
                    >
                      {appleIcon}
                      <span>
                        {isLogin ? appleLabelSignIn : appleLabelSignUp}
                      </span>
                    </button>
                  )}
                </div>
              </>
            )}

            {error && (
              <p
                role="alert"
                className="mt-3 w-full rounded-[6px] border border-red-500/30 bg-red-500/10 px-3 py-2 text-left text-[0.8rem] leading-snug text-red-300"
              >
                {error}
              </p>
            )}

            {info && (
              <p
                role="status"
                className="mt-3 w-full rounded-[6px] border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-left text-[0.8rem] leading-snug text-emerald-200"
              >
                {info}
              </p>
            )}

            {showModeSwitch && (
              <div className="mt-5 text-[0.875rem] text-[#888]">
                {isLogin ? switchToSignUpText : switchToSignInText}{" "}
                <button
                  type="button"
                  disabled={disabled}
                  onClick={() => setMode(isLogin ? "signup" : "signin")}
                  className="border-0 bg-transparent p-0 font-medium text-white underline-offset-4 hover:underline disabled:opacity-50"
                >
                  {isLogin ? switchToSignUpAction : switchToSignInAction}
                </button>
              </div>
            )}

            <div
              className={cn(
                "text-center text-[0.75rem] leading-normal text-[#666]",
                showModeSwitch ? "mt-[0.85rem]" : "mt-5",
              )}
            >
              {legalContent ?? (
                <>
                  By proceeding, you agree to creating an account
                  <br />
                  subject to our{" "}
                  <a
                    href={termsHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#888] underline underline-offset-2 hover:text-white"
                  >
                    Terms of Service
                  </a>{" "}
                  and{" "}
                  <a
                    href={privacyHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#888] underline underline-offset-2 hover:text-white"
                  >
                    Privacy Policy
                  </a>
                  .
                </>
              )}
            </div>
          </div>
        </motion.section>
      </main>
    </div>
  );
}

export default ModernLoginSignup;
