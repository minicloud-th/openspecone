import * as React from "react";

export type IndicatorRect = {
  left: number;
  top: number;
  width: number;
  height: number;
};

export function computeIndicatorRect(
  containerRect: Pick<DOMRect, "left" | "top">,
  targetRect: Pick<DOMRect, "left" | "top" | "width" | "height">,
  scrollLeft: number,
  scrollTop: number,
): IndicatorRect {
  return {
    left: targetRect.left - containerRect.left + scrollLeft,
    top: targetRect.top - containerRect.top + scrollTop,
    width: targetRect.width,
    height: targetRect.height,
  };
}

export function rectsEqual(a: IndicatorRect | null, b: IndicatorRect | null): boolean {
  if (a === b) return true;
  if (!a || !b) return false;
  return (
    Math.abs(a.left - b.left) < 0.5 &&
    Math.abs(a.top - b.top) < 0.5 &&
    Math.abs(a.width - b.width) < 0.5 &&
    Math.abs(a.height - b.height) < 0.5
  );
}

export function useActiveIndicator(
  containerRef: React.RefObject<HTMLElement | null>,
  selector: string,
): IndicatorRect | null {
  const [rect, setRect] = React.useState<IndicatorRect | null>(null);

  const measure = React.useCallback(() => {
    const container = containerRef.current;
    if (!container) {
      setRect((prev) => (prev === null ? prev : null));
      return;
    }

    const active = container.querySelector<HTMLElement>(selector);
    if (!active) {
      setRect((prev) => (prev === null ? prev : null));
      return;
    }

    const next = computeIndicatorRect(
      container.getBoundingClientRect(),
      active.getBoundingClientRect(),
      container.scrollLeft,
      container.scrollTop,
    );

    setRect((prev) => (rectsEqual(prev, next) ? prev : next));
  }, [containerRef, selector]);

  React.useLayoutEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    measure();

    const mutationObserver = new MutationObserver(() => {
      measure();
    });
    mutationObserver.observe(container, {
      attributes: true,
      attributeFilter: ["aria-current", "class", "style", "data-collapsed"],
      childList: true,
      subtree: true,
    });

    const resizeObserver = new ResizeObserver(() => {
      measure();
    });
    resizeObserver.observe(container);

    const active = container.querySelector<HTMLElement>(selector);
    if (active) {
      resizeObserver.observe(active);
    }

    window.addEventListener("resize", measure);
    return () => {
      mutationObserver.disconnect();
      resizeObserver.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, [containerRef, selector, measure]);

  return rect;
}
